package com.clouiotech.pda.demo.interfaces;

/**
 * Created by roka on 17/03/17.
 */

public interface CustomQueryOnClickListener  {
    void onQueryClicked(int id);
}

package com.clouiotech.pda.demo.Sqlite;

public class DataTemp {
	private String KODE;
	
	public DataTemp(){
		
	}
	
	public DataTemp(String _KODE){
		this.KODE = _KODE;
	}
	
	public void setKODE(String _KODE){
		this.KODE = _KODE;
	}
	public String getKODE(){
		return this.KODE;
	}
}
